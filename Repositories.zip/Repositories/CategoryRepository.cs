﻿using Payald.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using Payald.Models;

namespace Payald.Repositories
{
    public class CategoryRepository
    {
       
    
        // Replace with your actual database connection string
        private readonly string connectionString = "Data Source=DESKTOP-ENOK4H3\\SQLEXPRESS;Initial Catalog=Assignment;Integrated Security=True;Encrypt=False";

        public List<Category> GetAllCategories()
        {
            var categories = new List<Category>();

            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("SELECT * FROM CategoryMaster", connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            categories.Add(new Category
                            {
                                CategoryId = reader.GetInt32(0),
                                CategoryName = reader.GetString(1)
                            });
                        }
                    }
                }
            }

            return categories;
        }

        public Category GetCategoryById(int id)
        {
            Category category = null;

            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("SELECT * FROM CategoryMaster WHERE CategoryId = @CategoryId", connection))
                {
                    command.Parameters.AddWithValue("@CategoryId", id);
                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            category = new Category
                            {
                                CategoryId = reader.GetInt32(0),
                                CategoryName = reader.GetString(1)
                            };
                        }
                    }
                }
            }

            return category;
        }

        public void AddCategory(Category category)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("INSERT INTO CategoryMaster (CategoryName) VALUES (@CategoryName)", connection))
                {
                    command.Parameters.AddWithValue("@CategoryName", category.CategoryName);
                    command.ExecuteNonQuery();
                }
            }
        }

        public void UpdateCategory(Category category)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("UPDATE CategoryMaster SET CategoryName = @CategoryName WHERE CategoryId = @CategoryId", connection))
                {
                    command.Parameters.AddWithValue("@CategoryName", category.CategoryName);
                    command.Parameters.AddWithValue("@CategoryId", category.CategoryId);
                    command.ExecuteNonQuery();
                }
            }
        }

        public void DeleteCategory(int id)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("DELETE FROM CategoryMaster WHERE CategoryId = @CategoryId", connection))
                {
                    command.Parameters.AddWithValue("@CategoryId", id);
                    command.ExecuteNonQuery();
                }
            }
        }
    }

}
    
